import { AccountCircle, Message } from "@mui/icons-material";
import {
    Box,
    Card,
    CardContent,
    Divider,
    Grid,
    Stack,
    Typography,
    Button,
    Badge
} from "@mui/material";
import { motion } from "framer-motion";
import { blogData } from "./blogData";
import { useNavigate } from "react-router-dom";

const LatestBlog = () => {
    const navigate = useNavigate();

    const handleClick = (id) => {
        navigate(`/singleblogs/${id}`);
    };

    return (
        <Box sx={{ my: 2, px: { xs: 1, sm: 2, md: 4, lg: 8, xl: 10, xxl: 12 } }}>
            <Typography variant="h4" sx={{ mb: 3, fontWeight: "bold", textAlign: 'center' }}>
                Latest Blog
            </Typography>
            <Grid container spacing={2}>
                {blogData.splice(3, 5).map((blog) => (
                    <Grid key={blog.id} item xs={12} sm={6} md={4} lg={4} xl={3} xxl={3}>
                        <Card
                            elevation={0}
                            sx={{
                                background: "#fff",
                                position: "relative",
                                height: "100%",
                                borderRadius: "10px",
                                overflow: "hidden",

                            }}
                        >
                            {/* Motion Background Image */}
                            <motion.div
                                whileHover={{ scale: 1.05 }}
                                transition={{ duration: 0.3, ease: "easeOut" }}
                                style={{
                                    height: "250px",
                                    width: "100%",
                                    background: `url(${blog.imagePath})`,
                                    backgroundSize: "cover",
                                    backgroundPosition: "center",
                                    position: "relative",
                                    transition: "transform 0.3s ease-in-out",
                                    "&:hover": {
                                        transform: "scale(1.03)"
                                    }
                                }}
                            >
                                {/* Hover Overlay */}
                                <motion.div
                                    whileHover={{ background: "rgba(0,0,0,0.5)" }}
                                    style={{
                                        position: "absolute",
                                        top: 0,
                                        left: 0,
                                        width: "100%",
                                        height: "100%",
                                        transition: "background 0.3s ease",
                                        background: "rgba(0,0,0,0.3)"
                                    }}
                                />
                            </motion.div>

                            {/* Blog Date Tag */}
                            <Box sx={{
                                top: 10,
                                left: 10,
                                borderRadius: "10px",
                                position: "absolute",
                                px: 2,
                                py: 1,
                                background: "#FFFFFF"
                            }}>
                                <Typography variant="body2" fontWeight="bold" color="primary.dark">
                                    {blog.createDate}
                                </Typography>
                            </Box>

                            {/* Blog Author & Comments */}
                            <Box sx={{ px: 3, position: 'relative', bottom: 40 }}>
                                <Stack direction="row" spacing={2} alignItems="center" justifyContent="space-between">
                                    <Typography display="flex" alignItems="center" sx={{ color: '#fefefe' }} variant="body2">
                                        <AccountCircle sx={{ mr: 1 }} /> {blog.createdBy}
                                    </Typography>
                                    <Badge color="secondary" badgeContent={blog.comment} showZero>
                                        <Message sx={{ color: '#fdfdfd' }} />
                                    </Badge>
                                </Stack>
                            </Box>

                            {/* Blog Content */}
                            <CardContent>
                                <Typography variant="h6" fontWeight="bold">
                                    {blog.heading}
                                </Typography>
                                <Divider sx={{ my: 1 }} />
                                <Typography variant="body2" color="text.secondary">
                                    {blog.description.length > 100
                                        ? `${blog.description.substring(0, 100)}...`
                                        : blog.description}
                                </Typography>
                                <Button variant="outlined" sx={{ mt: 2 }} onClick={() => handleClick(blog.id)}>
                                    Read More
                                </Button>
                            </CardContent>
                        </Card>
                    </Grid>
                ))}
            </Grid>
        </Box>
    );
};

export default LatestBlog;
