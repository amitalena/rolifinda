import BlogComponent from "../../utils/BlogComponent";
import { blogData } from "./blogData";

const SingleBlogPage = () => {
    const mainBlog = blogData.find(blog => blog.id === 1);
    const latestBlogs = blogData.filter(blog => blog.id !== 1);

    return (
        <BlogComponent
            blog={mainBlog}
            latestBlogs={latestBlogs}
        />
    );
};

export default SingleBlogPage;