import F1 from '../../assets/images/interior/f1.webp';
import F2 from '../../assets/images/interior/f2.webp';
import F3 from '../../assets/images/interior/f3.webp';
import F4 from '../../assets/images/interior/f4.webp';
import T1 from '../../assets/images/tiles/t1.webp';
import T2 from '../../assets/images/tiles/t2.webp';
import T3 from '../../assets/images/tiles/t3.webp';
import T4 from '../../assets/images/tiles/t4.webp';
import L1 from '../../assets/images/electric/e1.webp';
import L2 from '../../assets/images/electric/e2.webp';
import L3 from '../../assets/images/electric/e3.webp';
import L4 from '../../assets/images/electric/e4.webp';

export const blogData = [
    {
        id: 1,
        imagePath: F1,
        heading: "Modern Minimalist Furniture Trends for 2024",
        createdBy: "Admin",
        comment: "3",
        createDate: "12/02/25",
        description: "Discover the latest trends in modern minimalist furniture and how to incorporate them into your home for a sleek, contemporary look."
    },
    {
        id: 2,
        imagePath: F2,
        heading: "Eco-Friendly Furniture: Sustainable Choices for Your Home",
        createdBy: "Admin",
        comment: "5",
        createDate: "13/02/25",
        description: "Explore eco-friendly furniture options that combine sustainability with style, perfect for environmentally conscious homeowners."
    },
    {
        id: 3,
        imagePath: F3,
        heading: "Maximizing Small Spaces with Multi-Functional Furniture",
        createdBy: "Admin",
        comment: "2",
        createDate: "14/02/25",
        description: "Learn how multi-functional furniture can help you make the most of small spaces without compromising on design or comfort."
    },
    {
        id: 4,
        imagePath: T1,
        heading: "The Art of Mixing Vintage and Modern Furniture",
        createdBy: "Admin",
        comment: "7",
        createDate: "15/02/25",
        description: "Find out how to blend vintage and modern furniture pieces to create a unique and timeless interior design."
    },
    {
        id: 5,
        imagePath: T2,
        heading: "Top 5 Luxurious Furniture Pieces for Your Living Room",
        createdBy: "Admin",
        comment: "6",
        createDate: "16/02/25",
        description: "Upgrade your living room with these top 5 luxurious furniture pieces that exude elegance and sophistication."
    },
    {
        id: 6,
        imagePath: T3,
        heading: "How to Choose the Perfect Dining Table for Your Home",
        createdBy: "Admin",
        comment: "4",
        createDate: "17/02/25",
        description: "A comprehensive guide to selecting the ideal dining table that fits your space, style, and lifestyle."
    },
    {
        id: 7,
        imagePath: L1,
        heading: "Creating a Cozy Bedroom with the Right Furniture",
        createdBy: "Admin",
        comment: "1",
        createDate: "18/02/25",
        description: "Transform your bedroom into a cozy retreat with the perfect furniture choices and layout tips."
    },
    {
        id: 8,
        imagePath: L2,
        heading: "Outdoor Furniture: Stylish and Durable Options for Your Patio",
        createdBy: "Admin",
        comment: "8",
        createDate: "19/02/25",
        description: "Discover stylish and durable outdoor furniture options to create a welcoming and functional patio space."
    },
    {
        id: 9,
        imagePath: L3,
        heading: "The Rise of Smart Furniture: Technology Meets Design",
        createdBy: "Admin",
        comment: "9",
        createDate: "20/02/25",
        description: "Explore how smart furniture is revolutionizing interior design with innovative features and cutting-edge technology."
    },
    {
        id: 10,
        imagePath: F4,
        heading: "Maximizing Small Spaces with Multi-Functional Furniture",
        createdBy: "Admin",
        comment: "2",
        createDate: "14/02/25",
        description: "Learn how multi-functional furniture can help you make the most of small spaces without compromising on design or comfort."
    },
    {
        id: 11,
        imagePath: T4,
        heading: "Maximizing Small Spaces with Multi-Functional tiles",
        createdBy: "Admin",
        comment: "2",
        createDate: "14/02/25",
        description: "Learn how multi-functional furniture can help you make the most of small spaces without compromising on design or comfort."
    },
    {
        id: 12,
        imagePath: L4,
        heading: "Maximizing Small Spaces with Multi-Functional lights",
        createdBy: "Admin",
        comment: "2",
        createDate: "14/02/25",
        description: "Learn how multi-functional furniture can help you make the most of small spaces without compromising on design or comfort."
    },
];
