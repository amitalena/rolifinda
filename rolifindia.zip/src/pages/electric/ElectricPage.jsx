import { useNavigate } from "react-router-dom";
import SliderComponent from "../../utils/SpliderComponent";
import { electricItemsData } from "./electricData";



const ElectricPage = () => {
    const navigate = useNavigate();

    const handleElectricPageClick = (id) => {
        navigate(`/singleelectric/${id}`);
    };

    return (
        <SliderComponent
            data={electricItemsData}
            title="Shop Electric"
            onClick={handleElectricPageClick}
        />
    );
};

export default ElectricPage;