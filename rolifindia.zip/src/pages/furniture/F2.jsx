import { Box, Stack } from '@mui/material'
import Img1 from '../..//assets/images/interior/f2.webp'
import Furniture from './Furniture';
import { Grid } from '@mui/material';
const F2 = () => {
    return (
        <>
            <Grid container>
                <Grid item xs={12} lg={3}>
                    <Stack sx={{ height: '350px', width: '100%' }}>
                        <Box
                            component="img"
                            src={Img1}
                            alt="img1"
                            sx={{ height: "100%", width: "100%", }}
                        />
                    </Stack>
                </Grid>
                <Grid item xs={12} lg={9}>
                    <Furniture />
                </Grid>
            </Grid>
        </>
    )
}

export default F2