import { useNavigate } from "react-router-dom";
import SliderComponent from "../../utils/SpliderComponent";
import { furnitureData } from "./furnitureData";



const Furniture = () => {
    const navigate = useNavigate();

    const handleFurniturePageClick = (id) => {
        navigate(`/singleblogs/${id}`);
    };

    return (

        <SliderComponent
            data={furnitureData}
            title="Shop Furniture"
            onClick={handleFurniturePageClick}
        />
    );
};

export default Furniture;