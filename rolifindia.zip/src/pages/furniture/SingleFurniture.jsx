import BlogComponent from "../../utils/BlogComponent";
import { furnitureData } from "./furnitureData";

const SingleFurniture = () => {
    const mainBlog = furnitureData.find(blog => blog.id === 1);
    const latestBlogs = furnitureData.filter(blog => blog.id !== 1);

    return (
        <BlogComponent
            blog={mainBlog}
            latestBlogs={latestBlogs}
        />
    );
};

export default SingleFurniture;
