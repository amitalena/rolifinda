import { Box, Stack, Typography } from "@mui/material";
import { Splide, SplideSlide } from "@splidejs/react-splide";
import "@splidejs/splide/dist/css/splide.min.css";
import { testiData } from "./testData";

const OurTestimonial = () => {
    return (
        <Box sx={{ width: { xl: "86vw", md: "77vw", xs: '100vw' }, background: "#F0F2F9", px: { md: 2, lg: 12, xl: 12, xs: 2 }, }}>
            {/* Header */}
            <Box>
                <Typography variant="h2" fontWeight={'bold'} sx={{ fontWeight: "bold", textAlign: 'center', py: 2 }}>
                    Testminials
                </Typography>
            </Box>

            {/* Splide Slider */}
            <Splide
                options={{
                    type: "loop",
                    autoplay: true,
                    interval: 3000,
                    arrows: true,
                    pagination: false,
                    pauseOnHover: false,
                    perPage: 4,
                    breakpoints: {
                        1980: { perPage: 1 }, // xxl
                        1368: { perPage: 1 }, // xl
                        1024: { perPage: 1 }, // lg
                        768: { perPage: 1 }, // md
                        480: { perPage: 1 }, // sm
                        0: { perPage: 1 }, // xs
                    },
                }}
            >

                {testiData.map((item) => (
                    <SplideSlide key={item.id} style={{ display: "flex", justifyContent: "center" }}>
                        <Stack direction={'row'} spacing={3} alignItems={'center'}>
                            <Box sx={{ px: 10 }}>
                                <Typography variant="h4">{item.name}</Typography>
                                <Typography variant="body2">{item.description}</Typography>
                            </Box>
                            <Box sx={{ height: '200px', width: '200px', }}>
                                <img src={item.imagePath} style={{ borderRadius: '50%', height: '100%', width: '100%' }} />
                            </Box>
                        </Stack>
                    </SplideSlide>
                ))}
            </Splide>
        </Box>
    );
};

export default OurTestimonial;