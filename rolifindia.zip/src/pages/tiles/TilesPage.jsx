import { useNavigate } from "react-router-dom";
import SliderComponent from "../../utils/SpliderComponent";
import { tileData } from './tilesData';


const TilesPage = () => {
    const navigate = useNavigate();

    const handleTilesPageClick = (id) => {
        navigate(`/singletiles/${id}`);
    };

    return (
        <SliderComponent
            data={tileData}
            title="Shop Latest Tiles"
            onClick={handleTilesPageClick}
        />
    );
};

export default TilesPage;