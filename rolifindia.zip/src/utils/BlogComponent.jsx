import { Box, Grid, Stack, Typography, useTheme, Card, CardMedia, Toolbar } from "@mui/material";
import SingleBlogCard from "./SingleBlogCard";
import I1 from "../assets/images/interior/f7.webp";


const BlogComponent = ({ blog, latestBlogs }) => {
    const { palette } = useTheme();

    return (
        <>
            <Toolbar />
            <Box sx={{ mt: 10, px: { lg: 8, md: 2, xs: 1 } }}>
                <Grid container spacing={3}>
                    {/* Main Blog */}
                    <Grid item xs={12} lg={8}>
                        <Stack spacing={2}>
                            <Card sx={{ height: "80vh", width: "100%", overflow: "hidden", boxShadow: 3 }}>
                                <CardMedia
                                    component="img"
                                    image={I1}
                                    alt="Main Blog Image"
                                    sx={{ height: "100%", width: "100%", objectFit: "cover" }}
                                />
                            </Card>
                            <Typography variant="h4" fontWeight="bold">
                                {blog.title}
                            </Typography>
                            <Typography variant="body1">{blog.createDate}</Typography>
                            <Typography variant="body2">{blog.description}</Typography>
                        </Stack>
                    </Grid>

                    {/* Latest Blogs Section */}
                    <Grid item xs={12} lg={4}>
                        <Stack spacing={2}>
                            {latestBlogs.map((latestBlog) => (
                                <SingleBlogCard
                                    key={latestBlog.id}
                                    blog={latestBlog}
                                    image={I1}
                                    onClick={() => console.log("Navigate to blog:", latestBlog.id)}
                                />
                            ))}
                        </Stack>
                    </Grid>
                </Grid>
            </Box>
        </>
    );
};

export default BlogComponent;