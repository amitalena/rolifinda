import { Card, CardMedia, Stack, Typography } from "@mui/material";

const SingleBlogCard = ({ blog, image, onClick }) => {
    return (
        <Card
            sx={{
                display: "flex",
                alignItems: "center",
                gap: 2,
                p: 2,
                boxShadow: 1,
                cursor: "pointer"
            }}
            onClick={onClick}
        >
            <CardMedia
                component="img"
                image={image}
                alt="Blog Image"
                sx={{ height: "10vh", width: "20vw", objectFit: "cover", borderRadius: 1 }}
            />
            <Stack>
                <Typography variant="h6">{blog.title}</Typography>
                <Typography variant="body2">{blog.createDate}</Typography>
            </Stack>
        </Card>
    );
};

export default SingleBlogCard;